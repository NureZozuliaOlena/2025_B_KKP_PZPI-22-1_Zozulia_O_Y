﻿namespace findspot_backend.DbInitializer
{
    public interface IDbInitializer
    {
        void Initialize();
    }
}