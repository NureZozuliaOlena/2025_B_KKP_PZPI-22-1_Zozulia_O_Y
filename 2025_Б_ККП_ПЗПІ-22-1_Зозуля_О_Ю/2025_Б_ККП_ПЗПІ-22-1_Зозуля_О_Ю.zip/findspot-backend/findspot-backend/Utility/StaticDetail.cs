﻿namespace findspot_backend.Utility
{
    public class StaticDetail
    {
        public const string Role_Admin = "Admin";
        public const string Role_Moderator = "Moderator";
        public const string Role_User = "User";
    }
}
